# Geely Edge Pro

Geely Edge Pro is a premium edge-dock launcher for Geely-compatible Android head units. It provides a clean floating shortcut panel, configurable app slots, split-launch shortcuts, app control utilities, and launcher/widget integration for large vertical car displays.

This project is independent software for compatible Android head units. It does not use official Geely branding, logos, or proprietary APIs.

## Highlights

- Floating edge handle with a large, driver-friendly shortcut dock
- Live top/bottom split picker with `+` buttons for any installed app
- One-tap return to the previous app from the floating EDGE panel
- Quick Back and recent-app close controls from the overlay
- User-selected app slots from installed launchable apps
- Top/bottom split-launch modes for compatible firmware
- Home screen widget and launcher shortcut support
- App Control Center with open, close, info, and battery helper actions
- Optional Usage Access recents
- Optional Accessibility navigation assist for Home, Back, Recents, and split actions
- Boot support for restoring the floating edge handle
- Local-only preferences; no network dependency

## Target Environment

- Android-based Geely-compatible head unit
- Portrait/vertical 2K-style display
- APK sideloading through file manager, USB, or an existing installer path
- Display over other apps permission for the floating edge dock

## Build

Open the project in Android Studio and build the `app` module.

Recommended local commands:

```powershell
$env:JAVA_HOME='C:\Program Files\Android\Android Studio\jbr'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat assembleRelease
```

The release build enables R8 shrinking and obfuscation. The current project signs the release with the debug signing config for direct head-unit sideload installs. Replace this with your own signing config before public distribution.

## Install

1. Build or copy the APK to USB.
2. Install it on the head unit.
3. Open `EDGE_PRO`.
4. Grant Display over other apps.
5. Tap `EDGE`.
6. Add the apps you want in the dock.
7. Configure split shortcuts only for app pairs you actually use.
8. Disable battery optimization for `EDGE_PRO` if the overlay is stopped by firmware.

## Split Launching

True split behavior depends on the head-unit firmware and on whether the target apps allow resizing. Geely Edge Pro includes multiple launch modes:

- HU Top / Bottom Split
- Normal Sequential Launch
- Accessibility Assisted Mode

Start with HU Top / Bottom Split. If the head unit blocks split-screen for a specific app pair, use Accessibility Assisted Mode or Normal Sequential Launch.

## Privacy

Geely Edge Pro stores configuration locally on the head unit. It may read the installed launcher app list so the user can choose shortcuts. Usage Access and Accessibility are optional and are only used for the visible features described in the app.

No internet connection is required.

## Project Status

Release target: `1.0.0`

Primary APK name for sideloading:

```text
Geely_Edge_Pro.apk
```

## License

Private project unless a license file is added.
